from django import forms
from .models import*






class UserReg(forms.ModelForm):
    class Meta:
        model = userLogin
        fields =['DonarName','Password','Gender','Address','Contact','Email','Occupation','Annual_Income']


class OrpForm(forms.ModelForm):
    class Meta:
        model = orphan
        fields = ['Orphan_ID','Orphan_Name','Orphan_Age','Gender','D_O_B','Gurdian_Name','Gurdian_Occupation',
                 'Gaurdian_Age','Gaurdian_Address','Gaurdian_Phone','Gaurdian_Email','Date_of_joining']

"""class donationform(forms.ModelForm):
    class Meta:
        model = donation
        fields = "__all__" """

class EmpForm(forms.ModelForm):
    class Meta:
        model=employee
        fields="__all__"
        

class inventryForm(forms.ModelForm):
    class Meta:
        model=inventry
        fields = ['Asset_Name','Available','Wanted']

