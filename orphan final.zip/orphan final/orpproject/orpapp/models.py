from django.db import models

# Create your models here.
class userLogin(models.Model):
    DonarName=models.CharField(max_length=100)
    Password=models.CharField(max_length=100)
    Gender=models.CharField(max_length=100)
    Address=models.CharField(max_length=100,null=True)
    Contact=models.CharField(max_length=100)
    Email=models.CharField(max_length=100)
    Occupation=models.CharField(max_length=100)
    Annual_Income=models.CharField(max_length=100)
    
    class Meta:
        db_table="userLogin"




class orphan(models.Model):
    Orphan_ID=models.CharField(max_length=40)
    Orphan_Name=models.CharField(max_length=40)
    Orphan_Age=models.CharField(max_length=100)
    Gender=models.CharField(max_length=100)
    D_O_B=models.CharField(max_length=100)
    Gurdian_Name=models.CharField(max_length=100)
    Gurdian_Occupation=models.CharField(max_length=100)
    Gaurdian_Age=models.CharField(max_length=200)
    Gaurdian_Address=models.CharField(max_length=200)
    Gaurdian_Phone=models.CharField(max_length=100)
    Gaurdian_Email=models.CharField(max_length=100)
    Date_of_joining=models.CharField(max_length=100)

    class Meta:
        db_table='orphan'        
class donation(models.Model):
    Donation_Name=models.CharField(max_length=1000)
    Donation_Image=models.FileField(upload_to="images/%y")
    Donation_Collection_Address=models.CharField(max_length=200)
    Description=models.CharField(max_length=200)
    DonarName=models.CharField(max_length=100)
    Ac_NO=models.CharField(max_length=200)
    IFSC=models.CharField(max_length=200,)
    Contact=models.CharField(max_length=200)
    BankName=models.CharField(max_length=200)
    Branch=models.CharField(max_length=200)
    Amount=models.CharField(max_length=200)
    Status=models.CharField(max_length=200)
    Email=models.CharField(max_length=200)
    Date=models.DateField(max_length=200)
    Mstatus=models.CharField(max_length=200)
    class Meta:
        db_table='donation'

class donationm(models.Model):
    
    Description=models.CharField(max_length=200)
    DonarName=models.CharField(max_length=100)
    Ac_NO=models.CharField(max_length=200)
    IFSC=models.CharField(max_length=200,)
    Contact=models.CharField(max_length=200)
    BankName=models.CharField(max_length=200)
    Branch=models.CharField(max_length=200)
    Amount=models.CharField(max_length=200)
    Status=models.CharField(max_length=200)
    Email=models.CharField(max_length=200)
    Date=models.DateField(max_length=200)
    
    class Meta:
        db_table='donationm'

class employee(models.Model):
    Name=models.CharField(max_length=50)
    Date_Of_Birth=models.CharField(max_length=30)
    Gender=models.CharField(max_length=20)
    Email=models.CharField(max_length=50)
    Contact=models.CharField(max_length=10)
    Emergency_Contact=models.CharField(max_length=10)
    Address=models.CharField(max_length=200)
    Qualification=models.CharField(max_length=10)
    Blood_Group=models.CharField(max_length=10)
    Aadhar_No=models.CharField(max_length=12)
    PAN_No=models.CharField(max_length=10)
    Bank_Name=models.CharField(max_length=50)    
    Bank_Account_No=models.CharField(max_length=20)
    Branch_Name=models.CharField(max_length=50)
    IFSC_Code=models.CharField(max_length=15)

    class Meta:
        db_table="employee"

class inventry(models.Model):
    Asset_Name=models.CharField(max_length=40)
    Available=models.CharField(max_length=100)
    Wanted=models.CharField(max_length=100)

    class Meta:
        db_table='inventry'


