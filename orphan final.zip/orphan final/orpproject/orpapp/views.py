from django import forms
from django.db.models import Q
from django.shortcuts import render,redirect,HttpResponse,HttpResponseRedirect
from orpapp.forms import *
from orpapp.models import *
from django.core.mail import send_mail,BadHeaderError
from orpproject.settings import EMAIL_HOST_USER
from django.contrib import messages
from orpapp.functions import handle_uploaded_file 
import csv
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate



# Create your views here.
global xval,yval,kval,sd                                                                 
def homepage(request):
    return render(request,"homepage.html")

#user SignUp Page Details
def usign(request):
    return render(request,'usignup.html',{'form:data'})

def usignup(request):
    if request.method=="POST":
        form=UserReg(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Regiter successfully.')
            return redirect('/')
        else:
            return HttpResponse("Invalid data")
    else:
        data=UserReg
        return render(request,'usignup.html',{'form':data})  

def donarview(request):
    
    if request.method == 'POST':
        sd = request.POST['searchdata']
        
        try:
            form = userLogin.objects.filter(Q(DonarName=sd))
        except:
            form = ""
    return render(request, 'viewdonar.html', locals())
    

# def donarview(request):
    
#     data=userLogin.objects.get(DonarName)
#     print(data.DonarName)
#     return render(request, 'viewdonar.html', locals())

def editdonar(request,id):
    data=userLogin.objects.get(id=id)
    return render(request,'editdonar.html',{'form':data})    


def updatedonar(request,id):
    if request.method=="POST":
        data=userLogin.objects.get(id=id)
        form=UserReg(request.POST,instance=data)
        if form.is_valid():
            form.save()
            messages.success(request, 'Details Update successfully.')
            return redirect('/viewdonar')
        else:
            return HttpResponse("Invalid data")
    else:
        data=orphan.objects.get(id=id)
        return render(request,'editdonar.html',{'form':data})
  
#User Login
def log(request):
    return render(request,"ulogin.html")

def log1(request):
    if request.method=='POST':
      
        if userLogin.objects.filter(DonarName=request.POST['DonarName'],Password=request.POST['Password']).exists():
            x=userLogin.objects.get(DonarName=request.POST['DonarName'],Password=request.POST['Password'])
           # messages.success(request, 'Login successfully.')
            return redirect('/uhome')
        else:
            context = {'msg': 'Invalid username or password'}
            return render(request,"ulogin.html", context)

def logout(request):
    logout(request)
    return redirect('/')
#User home page
def uhome(request):
    return render(request,"umenu.html")

#Donation Form
def product(request):
    if request.method=='POST':
        x=donation(DonarName=request.POST['DonarName'],Email=request.POST['Email'],Date=request.POST['Date'],Donation_Name=request.POST['Donation_Name'],Donation_Collection_Address=request.POST['Donation_Collection_Address'], Description=request.POST['Description'])
        x.save()
        messages.success(request, 'Donate successfully.')
        return redirect('/prod')
        
    else:
        return render(request,'donation.html')

def pview(request):
    x=donation.objects.all()
    return render(request,'productview.html',{'data':x})

#Cash Donation
def cash(request):
    if request.method=='POST':
        x=donationm(DonarName=request.POST['DonarName'],Email=request.POST['Email'],Date=request.POST['Date'],Amount=request.POST['Amount'],BankName=request.POST['BankName'],Branch=request.POST['Branch'], Ac_NO=request.POST['Ac_NO'],IFSC =request.POST['IFSC'],Description=request.POST['Description'])
        x.save()
        messages.success(request, 'Donate successfully.')
        return redirect('/cash')
    else:
        return render(request,'cashdonate.html')

def cview(request):
    x=donationm.objects.all()
    return render(request,'cashview.html',{'data':x})

def viewdonations(request):
    forms=donation.objects.all()
    return render(request,"viewdonation.html",{'data':forms})




#admin Login Page
def alog(request):
    return render(request,"alogin.html")


def alog1(request):
    error = ""
    if request.method == 'POST':
        u = request.POST['username']
        p = request.POST['password']
        user = authenticate(username=u, password=p)
        try:
            if user.is_staff:
                login(request, user)
                error = "no"
            else:
                error = "yes"
        except:
            error = "yes"
    return render(request, 'alogin.html', locals()) 
      

def alogou(request):
    logout(request)
    return redirect('/')


#admin home page
def ahome(request):
    return render(request,"amenu.html")

#orphanform
def index(request):
    data=OrpForm
    return render(request,'index.html',{'form':data})


def sub(request):
    if request.method == 'POST':
        form = OrpForm(request.POST)
        if form.is_valid(): 
            form.save()
            forms = OrpForm
            messages.success(request,"Details Added successfully")
            return redirect('/reg')
           # return render(request, 'view.html', {'data': forms})
        else:
            forms = OrpForm
            messages.error(request,"Details Add Unsuccessfull")
            return render(request,'index.html',{'form':forms})
    else:
        forms = OrpForm
        return render(request,'index.html',{'form':forms})

def viee(request):
    data=orphan.objects.all()
    return render(request,'view.html',{'data':data})

def orphan_report_export(request):
    response=HttpResponse(content_type='text/csv')
    writer=csv.writer(response)
    writer.writerow(['Orphan_Name','Orphan_Age','Gender','D_O_B','Gurdian_Name','Gurdian_Occupation','Gaurdian_Age','Gaurdian_Address','Gaurdian_Phone','Gaurdian_Email','Date_of_joining'])
    for creport in orphan.objects.all().values_list('Orphan_Name','Orphan_Age','Gender','D_O_B','Gurdian_Name','Gurdian_Occupation','Gaurdian_Age','Gaurdian_Address','Gaurdian_Phone','Gaurdian_Email','Date_of_joining'):
        writer.writerow(creport)
    response['Content-Disposition']='attachment;filename="OrphanReport.csv"'
    return response



def edit(request,id):
    data=orphan.objects.get(id=id)
    return render(request,'edit.html',{'form':data})


def update(request,id):
    if request.method=="POST":
        data=orphan.objects.get(id=id)
        form=OrpForm(request.POST,instance=data)
        if form.is_valid():
            form.save()
            messages.success(request,"Details Updated successfully")
            return redirect('/viewdetails')
        else:
            return HttpResponse("Invalid data")
    else:
        data=orphan.objects.get(id=id)
        messages.error(request,"Details Updates Unsuccessfull")
        return render(request,'edit.html',{'form':data})


def delete(request,id):
    data=orphan.objects.get(id=id)
    data.delete()
    messages.success(request,"Details Deleted Successfully")
    return redirect('/viewdetails')

#orphan employee details
def empdetails(request):
    forms= EmpForm
    return render(request,'emp.html',{'form':forms})



def sube(request):
    if request.method == 'POST':
        form = EmpForm(request.POST)
        if form.is_valid(): 
            form.save()
            forms = EmpForm
            messages.success(request,"Details Added successfully")
            return render(request, 'emp.html', {'data': forms})
        else:
            forms = EmpForm
            messages.error(request,"Details Add Unsuccessfull")
            return render(request,'emp.html',{'form':forms})
    else:
        forms = EmpForm
        return render(request,'emp.html',{'form':forms})

def viewemp(request):
    data=employee.objects.all()
    return render(request,'empview.html',{'data':data})

def emp_details_export(request):
    response=HttpResponse(content_type='text/csv')
    writer=csv.writer(response)
    writer.writerow(['Date_Of_Birth','Gender','Email','Contact','Emergency_Contact','Address','Qualification','Blood_Group','Aadhar_No','PAN_No','Bank_Name','Bank_Account_No','Branch_Name','IFSC_Code'])
    for creport in employee.objects.all().values_list('Date_Of_Birth','Gender','Email','Contact','Emergency_Contact','Address','Qualification','Blood_Group','Aadhar_No','PAN_No','Bank_Name','Bank_Account_No','Branch_Name','IFSC_Code'):
        writer.writerow(creport)
    response['Content-Disposition']='attachment;filename="Employee.csv"'
    return response

def editemp(request,id):
    data=employee.objects.get(id=id)
    return render(request,'editemp.html',{'form':data})


def updateemp(request,id):
    if request.method=="POST":
        data=employee.objects.get(id=id)
        form=EmpForm(request.POST,instance=data)
        if form.is_valid():
            form.save()
            messages.success(request,"Details Updated successfully")
            return redirect('/viewemp')
        else:
            return HttpResponse("Invalid data")
    else:
        data=orphan.objects.get(id=id)
        return render(request,'editemp.html',{'form':data})  

def deleteemp(request,id):
    data=employee.objects.get(id=id)
    data.delete()
    messages.success(request,"Details Deleted Successfully")
    return redirect('/viewemp')
 

 #inventry Creations
def inven(request):
    forms= inventryForm
    return render(request,'inven.html',{'form':forms})

def subinven(request):
    if request.method=="POST":
        form=inventryForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Details Add successfully")
            return redirect('/viewinven')
        else:
            return HttpResponse("Invalid data")
    else:
         data=inventryForm
         return render(request,'inven.html',{'form':data})  

def viewinven(request):
    data=inventry.objects.all()
    return render(request,'viewinven.html',{'data':data})

def Asset_report_export(request):
    response=HttpResponse(content_type='text/csv')
    writer=csv.writer(response)
    writer.writerow(['Asset_Name','Available','Wanted'])
    for creport in inventry.objects.all().values_list('Asset_Name','Available','Wanted'):
        writer.writerow(creport)
    response['Content-Disposition']='attachment;filename="AssetsReport.csv"'
    return response



def editinven(request,id):
    data=inventry.objects.get(id=id)
    return render(request,'editinven.html',{'form':data})


def updateinven(request,id):
    if request.method=="POST":
        data=inventry.objects.get(id=id)
        form=inventryForm(request.POST,instance=data)
        if form.is_valid():
            form.save()
            messages.success(request,"Details Updated successfully")
            return redirect('/viewinven')
        else:
            return HttpResponse("Invalid data")
    else:
        data=orphan.objects.get(id=id)
        return render(request,'editinven.html',{'form':data})  

def deleteinven(request,id):
    data=inventry.objects.get(id=id)
    data.delete()
    messages.success(request,"Details Deleted Successfully")
    return redirect('/viewinven')


#admin view donar details
def adminviewdonar(request):
    x=userLogin.objects.all()
    return render(request,'adminviewdonar.html',{'data':x})

#donar view donardetails
def donarviews(request):
    x=userLogin.objects.all()
    return render(request,'adminviewdonar.html',{'data':x})


#donarview product donation details
def donarviewproduct_donation(request):
    x="Waiting For Approval"
    data=donation.objects.filter(Status=x)
    return render(request,'donarviewproduct_donation.html',{'form':data})

def donarviewproduct_donation1(request):
    if request.method=="POST":
        fromdate=request.POST['fromdate']
        todate=request.POST['todate']
        kval=request.POST['filter']
        xval=fromdate
        yval=todate
        if kval=="Waiting For Approval":
            vreport=donation.objects.filter(Date__lte=todate,Date__gte=fromdate)
            return render(request,'donarviewproduct_donation.html',{"form":vreport})     
        elif kval=="Approved":
            vreport=donation.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'donarviewproduct_donation.html',{"form":vreport})
        elif kval=="Declined":
            vreport=donation.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'donarviewproduct_donation.html',{"form":vreport})
        elif sd=="searchdata":
            vreport=donation.objects.filter(Q(DonarName=sd))
            return render(request,'donarviewproduct_donation.html',{"form":vreport})

    else:
        x="Waiting For Approval"
        data=donation.objects.filter(Status=x)
        return render(request,'donarviewproduct_donation.html',{'form':data})

#donarview Money donation details
def donarviewmoney_donation(request):
    x="Waiting For Approval"
    data=donationm.objects.filter(Status=x)
    return render(request,'donarviewmoney_donation.html',{'form':data})

def donarviewmoney_donation1(request):
    if request.method=="POST":
        fromdate=request.POST['fromdate']
        todate=request.POST['todate']
        kval=request.POST['filter']
        xval=fromdate
        yval=todate
        if kval=="Waiting For Approval":
            vreport=donationm.objects.filter(Date__lte=todate,Date__gte=fromdate)
            return render(request,'donarviewmoney_donation.html',{"form":vreport})     
        elif kval=="Approved":
            vreport=donationm.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'donarviewmoney_donation.html',{"form":vreport})
        elif kval=="Declined":
            vreport=donationm.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'donarviewmoney_donation.html',{"form":vreport})
        elif sd=="searchdata":
            vreport=donation.objects.filter(Q(DonarName=sd))
            return render(request,'donarviewmoney_donation.html',{"form":vreport})
    else:
        x="Waiting For Approval"
        data=donationm.objects.filter(Status=x)
        return render(request,'donarviewmoney_donation.html',{'form':data})



#admin approve product donation
def pdonationapproval(request):
    x="Waiting For Approval"
    data=donation.objects.filter(Status=x)
    return render(request,'donationapproval.html',{'form':data})

def adminfilterstatus(request):
    if request.method=="POST":
        fromdate=request.POST['fromdate']
        todate=request.POST['todate']
        kval=request.POST['filter']
        xval=fromdate
        yval=todate
        if kval=="Waiting For Approval":
            vreport=donation.objects.filter(Date__lte=todate,Date__gte=fromdate)
            return render(request,'donationapproval.html',{"form":vreport})     
        elif kval=="Approved":
            vreport=donation.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'donationapproval.html',{"form":vreport})
        elif kval=="Declined":
            vreport=donation.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'donationapproval.html',{"form":vreport})
    else:
        x="Waiting For Approval"
        data=donation.objects.filter(Status=x)
        return render(request,'donationapproval.html',{'form':data})

def approvereq(request,id):
    donation.objects.filter(id=id).update(Status="Approved")   
    x="Waiting For Approval"
    data=donation.objects.filter(Status=x)
    val=donation.objects.values_list('Email', flat=True)
    print(val)
    subject ="Donation Approval"
    message = 'Hi ,\n\n' 
    message1 = "Your donation request has approved."
    message2 = '\n\nThanks And Regards,\n' + "Admin Team"
    send_mail(subject,f'{message}{message1}{message2}',EMAIL_HOST_USER, val,fail_silently = False)
    
    return render(request,'donationapproval.html',{'form':data})


def declinereq(request,id):
    donation.objects.filter(id=id).update(Status="Declined")   
    x="Waiting For Approval"
    data=donation.objects.filter(Status=x)
    val=donation.objects.values_list('Email', flat=True)
    print(val)
    subject ="Donation Approval"
    message = 'Hi ,\n\n' 
    message1 = "Your donation request has declined."
    message2 = '\n\nThanks And Regards,\n' + "Admin Team"
    send_mail(subject,f'{message}{message1}{message2}',EMAIL_HOST_USER, val,fail_silently = False)
    messages.success(request,"request Declined")
    return render(request,'donationapproval.html',{'form':data})

def pdonation_report_export(request):
    response=HttpResponse(content_type='text/csv')
    writer=csv.writer(response)
    writer.writerow(['DonarName','Email','Date','Donation_Name','Donation_Collection_Address','Description','Status'])
    for creport in donation.objects.all().values_list('DonarName','Email','Date','Donation_Name','Donation_Collection_Address','Description','Status'):
        writer.writerow(creport)
    response['Content-Disposition']='attachment;filename="ProductReport.csv"'
    return response



#admin approve money donation
def mdonationapproval(request):
    x="Waiting For Approval"
    data=donationm.objects.filter(Status=x)
    return render(request,'moneydonationapproval.html',{'form':data})

def adminfilterstatus1(request):
    if request.method=="POST":
        fromdate=request.POST['fromdate']
        todate=request.POST['todate']
        kval=request.POST['filter']
        xval=fromdate
        yval=todate
        if kval=="Waiting For Approval":
            vreport=donationm.objects.filter(Date__lte=todate,Date__gte=fromdate)
            return render(request,'moneydonationapproval.html',{"form":vreport})     
        elif kval=="Approved":
            vreport=donationm.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'moneydonationapproval.html',{"form":vreport})
        elif kval=="Declined":
            vreport=donationm.objects.filter(Date__lte=todate,Date__gte=fromdate,Status=kval)
            return render(request,'moneydonationapproval.html',{"form":vreport})
    else:
        x="Waiting For Approval"
        data=donationm.objects.filter(Status=x)
        return render(request,'moneydonationapproval.html',{'form':data})

def approvereq1(request,id):
    donationm.objects.filter(id=id).update(Status="Approved")   
    x="Waiting For Approval"
    data=donationm.objects.filter(Status=x)
    val=donationm.objects.values_list('Email', flat=True)
    print(val)
    subject ="Donation Permission"
    message = 'Hi ,\n\n' 
    message1 = "Your donation request has approved."
    message2 = '\n\nThanks And Regards,\n' + "Admin Team"
    send_mail(subject,f'{message}{message1}{message2}',EMAIL_HOST_USER, val,fail_silently = False)
    
    return render(request,'moneydonationapproval.html',{'form':data})


def declinereq1(request,id):
    donationm.objects.filter(id=id).update(Status="Declined")   
    x="Waiting For Approval"
    data=donationm.objects.filter(Status=x)
    val=donationm.objects.values_list('Email', flat=True)
    print(val)
    subject ="Donation Permission"
    message = 'Hi ,\n\n' 
    message1 = "Your donation request has declined."
    message2 = '\n\nThanks And Regards,\n' + "Admin Team"
    send_mail(subject,f'{message}{message1}{message2}',EMAIL_HOST_USER, val,fail_silently = False)
    messages.success(request,"Request Declined")
    return render(request,'moneydonationapproval.html',{'form':data})

def Mdonation_report_export(request):
    response=HttpResponse(content_type='text/csv')
    writer=csv.writer(response)
    writer.writerow(['Donation_Name','Email','Date','Amount','BankName','Branch','Ac_NO','IFSC','Description','Status'])
    for creport in donationm.objects.all().values_list('Donation_Name','Email','Date','Amount','BankName','Branch','Ac_NO','IFSC','Description','Status'):
        writer.writerow(creport)
    response['Content-Disposition']='attachment;filename="MoneyReport.csv"'
    return response


def orphandetails(request):
    return render(request,"orphanagedetails.html")

def aboutus(request):
    return render(request,"aboutus.html")

######### User View orphan details ##########
def viewinven1(request):
    data=inventry.objects.all()
    return render(request,'viewinven1.html',{'data':data})

def admin_index(request):
    data = orphan.objects.all().count()
    data1 = employee.objects.all().count()
    data2 = inventry.objects.all().count()

    # client2 = BDMClient.objects.filter(Status="Converted").count()
    # Query = MyUser.objects.filter(Date_of_birth__day=today.day,Date_of_birth__month=today.month)
    # return render(request,'admin/admin_dashboard.html',locals())
    return render(request,"view_orp.html",locals())