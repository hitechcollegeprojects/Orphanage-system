from django.contrib import admin
from orpapp.models import*

# Register your models here.
admin.site.site_header="Sample Application"
admin.site.register(userLogin)

admin.site.register(orphan)

admin.site.register(donation)
admin.site.register(employee)
admin.site.register(inventry)
