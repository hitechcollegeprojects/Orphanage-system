"""orpproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from orpapp import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.homepage),
    path('usignup/',views.usignup),
    path('usig/',views.usign), 
    path('viewdonar/',views.donarview),
    path('editdonar/<int:id>',views.editdonar),
    path('updatedonar/<int:id>',views.updatedonar),
    path('aboutus/',views.aboutus),


    path('login/',views.log),
    path('test/',views.log1),
    path('logout/',views.logout),
    path('uhome/',views.uhome), 
  #donation
    path('prod/',views.product),
   # path('don/',views.dona),
    path('cash/',views.cash),
    path('cview/',views.cview),
    #path('cashd/',views.cashd),
    path('viewdonation/',views.viewdonations),
    path('donarviewproduct_donation/',views.donarviewproduct_donation),
    path('donarviewproduct_donation1/',views.donarviewproduct_donation1),
    path('donarviewmoney_donation/',views.donarviewmoney_donation),
    path('donarviewmoney_donation1/',views.donarviewmoney_donation1),
   
    #admmin 
    path('ahome/',views.ahome), 
    path('alogin/',views.alog),
    path('alogou/',views.alogou),
    path('atest/',views.alog1),
    path('orphandetails/',views.orphandetails),
    #orphan creation
    path('register/',views.index),
    path('reg/',views.sub),
    path('viewdetails/',views.viee),
    path('orphan_report_export/',views.orphan_report_export),
    path('edituser/<int:id>',views.edit),
    path('update/<int:id>',views.update),
    path('delete/<int:id>',views.delete),
   

    #admin aproval for product donation
    path('pdonationapproval/',views.pdonationapproval),
    path('admin-filter-status/',views.adminfilterstatus),
    path('approve/<int:id>',views.approvereq),
    path('decline/<int:id>',views.declinereq),
    path('pdonation_report_export/',views.pdonation_report_export),
    
    #admin approval for money donation
    path('mdonationapproval/',views.mdonationapproval),
    path('admin-filter-status1/',views.adminfilterstatus1),
    path('approve1/<int:id>',views.approvereq1),
    path('decline1/<int:id>',views.declinereq1),
    path('Mdonation_report_export/',views.pdonation_report_export),

    #adminviewemployee
    path('adminviewdonar/',views.adminviewdonar),
    #employee details
    path('empdetails/',views.empdetails),
    path('su/',views.sube),
    path('viewemp/',views.viewemp),
    path('emp_details_export/',views.emp_details_export),
    path('editemp/<int:id>',views.editemp),
    path('updateemp/<int:id>',views.updateemp),
    path('deleteemp/<int:id>',views.deleteemp),
    #inventry Creation & Details
    path('inven/',views.inven),
    path('subinven/',views.subinven),
    path('viewinven/',views.viewinven),
    path('Asset_report_export/',views.Asset_report_export),
    path('editinven/<int:id>',views.editinven),
    path('updateinven/<int:id>',views.updateinven),
    path('deleteinven/<int:id>',views.deleteinven),

     path('admin_index/',views.admin_index),
     path('viewinven1/',views.viewinven1),

]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
